import socket
from colorama import Fore, Style
import os

def get_port_type(port):
    # تحديد نوع البورت باستخدام مكتبة socket
    try:
        service = socket.getservbyport(port)
        return service
    except Exception as e:
        return "Unknown"

def scan_ip(ip):
    # فحص الآي بي كاملاً
    ports = range(1, 65536)  # جميع البورتات من 1 إلى 65535
    open_ports = []
    for port in ports:
        try:
            # إنشاء كائن socket
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # تجربة الاتصال بالعنوان IP والبورت المحدد
            result = s.connect_ex((ip, port))
            if result == 0:
                open_ports.append(port)
            s.close()
        except Exception as e:
            print(f"Error: {e}")
    return open_ports

def scan_single_port(ip, port):
    # فحص بورت معين
    try:
        # إنشاء كائن socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # تجربة الاتصال بالعنوان IP والبورت المحدد
        result = s.connect_ex((ip, port))
        s.close()
        if result == 0:
            return True
        else:
            return False
    except Exception as e:
        print(f"Error: {e}")
        return False

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# مسح الشاشة
clear_screen()  

# كتابة الشعار بألوان محددة بعد مسح الشاشة
print(Fore.GREEN + r"""
______          _     _____ _                                     
| ___ \        | |   /  ___| |                                    
| |_/ /__  _ __| |_  \ `--.| | __ _ _ __ ___  _ __ ___   ___ _ __ 
|  __/ _ \| '__| __|  `--. \ |/ _` | '_ ` _ \| '_ ` _ \ / _ \ '__|
| | | (_) | |  | |_  /\__/ / | (_| | | | | | | | | | | |  __/ |   
\_|  \___/|_|   \__| \____/|_|\__,_|_| |_| |_|_| |_| |_|\___|_|   
                                                                  
                                                                  
""" + Style.RESET_ALL)

# طلب من المستخدم اختيار طريقة الفحص
print("Choose an option:")
print("1. Scan entire IP")
print("2. Scan specific port")
option = input("Enter your choice (1 or 2): ")

if option == "1":
    # طلب عنوان IP من المستخدم
    ip = input("Please enter the IP address to scan: ")  
    open_ports = scan_ip(ip)

    # عرض البورتات المفتوحة بالشكل المطلوب مع نوع البورت
    if open_ports:
        print("Open ports:")
        for port in open_ports:
            port_type = get_port_type(port)
            print(f"|Port ({port} - {port_type})|")
            print("|")
    else:
        print(f"No open ports found on {ip}")

elif option == "2":
    # طلب عنوان IP ورقم البورت من المستخدم
    ip = input("Please enter the IP address: ")
    port = int(input("Please enter the port number to scan: "))
    result = scan_single_port(ip, port)
    if result:
        print(f"Port {port} is open on {ip}")
    else:
        print(f"Port {port} is closed on {ip}")

else:
    print("Invalid option. Please choose either 1 or 2.")